from django.db import models
from datetime import datetime
from decimal import Decimal

class modelCode(models.Model):
	#list of all languages
	lang_choices = (
		('C', 'C (gcc 4.8.4)'),
		('CPP', 'C++ (g++ 4.8.4)'),
		('CLOJURE', 'Clojure (clojure 1.4.0)'),
		('CSS', 'CSS'),
		('CSHARP', 'C# (mono 3.2.8)'),
		('GO', 'Go (go 1.4.2)'),
		('HASKELL', 'Haskell (ghc 7.6.3'),
		('HTML', 'HTML'),
		('JAVA', 'Java (openjdk 1.7.0_09)'),
		('JAVASCRIPT_NODE', 'JavaScript (Node.js 0.10.25)'),
		('LISP', 'Lisp (csc 4.8.0.5)'),
		('OBJECTIVE', 'Objective-C (clang 3.3)'),
		('PASCAL', 'Pascal (fpc 2.6.2)'),
		('PERL', 'Perl (perl 5.18.2)'),
		('PHP', 'PHP (php 5.5.9)'),
		('PYTHON', 'Python (python 2.7.6)'),
		('RUBY', 'Ruby (ruby 2.1.1)'),
		('R', 'R (RScript 3.0.2)'),
		('RUST', 'Rust (rustc 1.4.0)'),
		('SCALA', 'Scala (scalac 2.9.2)'),
		('TEXTFILE', 'Text'),
	)


	codearea = models.TextField(blank = True)
	inputs = models.TextField(blank = True)
	outputs = models.TextField(default = 'Standard output is empty', blank = True)
	langchoices = models.CharField(max_length=20, choices=lang_choices, default='C')
	date = models.DateTimeField(default = datetime.now, blank = True)
	result = models.CharField(max_length=5, default = 'IER')
	time = models.DecimalField(max_digits=2, decimal_places=2, default = Decimal('0.00'))
	mem = models.DecimalField(max_digits=5, decimal_places=2, default = Decimal('0.00'))
	status_detail = models.CharField(max_length=10, default = 'NA')

	def __unicode__(self):
		self.codearea