from django.shortcuts import render, render_to_response, redirect
from django.http import HttpResponse, HttpResponseRedirect
from django.template.loader import get_template
from django.template import Context
from django.views.generic.base import TemplateView
from codertable.models import modelCode
from forms import CodeForm
from django.core.context_processors import csrf
import requests
from decimal import Decimal


messages = (	
		"ArgumentMissingError: client_secret is needed!", 
		"UnregisteredClientError: Client does not exist", 
	)


Compile = {}
Run = {}
working_id = 0

def home(request):
	return render_to_response('boothome.html')

# demo request
def errorpage(request):
	HttpResponse('error page')


def earth_API(oper, *args):
	
	#EndPoints of API
	RUN_URL = {
		'compile': u'https://api.hackerearth.com/v3/code/compile/', 
		'run': u'https://api.hackerearth.com/v3/code/run/',
	}
	
	CLIENT_SECRET = 'a2061dc6289f46c3b117fd646c7bd455f586162e'

	data = {
	    'client_secret': CLIENT_SECRET,
	    'async': 0,
	    'source': args[1],
	    'lang': args[0],
	    'input': args[2],
	    'time_limit': 5,
	    'memory_limit': 262144,
	}

	r = requests.post(RUN_URL[oper], data=data)
	return r.json()

# For Compilation Error
def compilestatus(request):
	global Compile, working_id, Run
	a = modelCode.objects.get(id = working_id)
	a.result = 'CTE'
	a.save()
	return render(request, 'bootcompilestatus.html', {'X': Compile, 'R':Run})


# For Compile Messages
def compilemsg(request):
	global Compile
	return render(request, 'bootcompilemsg.html', {'X': Compile})


# For Run Status
def runstatus(request):
	global Run, working_id
	a = modelCode.objects.get(id = working_id)
	if Run["run_status"]["status"] == u'TLE': a.time = 5.00
	else:a.time = Decimal(Run["run_status"]["time_used"])
	a.mem = Decimal(Run["run_status"]["memory_used"])
	a.result = str(Run["run_status"]["status"])
	a.status_detail = str(Run["run_status"]["status_detail"])
	a.outputs = str(Run["run_status"]["output"])
	a.save()
	return render(request, 'bootrun.html', {'X':Run})

# Code, Compile, Run
def CodeCompileRun(request, form):
	global Compile, Run, working_id

	form_id = form.save()
	working_id = form_id.id
	
	lang = form.cleaned_data['langchoices']
	source = form.cleaned_data['codearea']
	inp = form.cleaned_data['inputs']

	Compile = earth_API('compile', lang, source, inp)
	
	if "message" in Compile.keys():
		if Compile["message"] in messages:
			return HttpResponseRedirect('/codertable/compilemsg/')

	if "compile_status" in Compile and Compile["compile_status"] != "OK":
		compile_error_msg = str(Compile["compile_status"])
		compile_error_msg = compile_error_msg.split('\n')
		Compile["compile_msg"] = compile_error_msg[:]

		return HttpResponseRedirect('/codertable/compilestatus/')

	Run = earth_API('run', lang, source, inp)
	print Run
	Compile["error_flag"] = "False"
	# To split on the basis of '\n'
	
	if "errors" in Run.keys():
		Compile["error_flag"] = "True"
		return HttpResponseRedirect('/codertable/compilestatus/')

	if Run["compile_status"]=="OK":
		output_view = str(Run["run_status"]["output"])
		output_view = output_view.split('\n')
		Run["output_view"] = output_view[:]
		return HttpResponseRedirect('/codertable/runstatus')
	
	#TLE CASE
	Run["run_status"]["status"] = u'TLE'
	return HttpResponseRedirect('/codertable/compilestatus/')

# New Submission
def create(request):
	global Compile, Run, working_id
	if request.POST:
		form = CodeForm(request.POST)
		if form.is_valid():
			form.save()
			return CodeCompileRun(request, form)
	else:
		form = CodeForm()
	return render(request,'bootcreate.html', {'form':form})


# Table of all codes
def AllCodes(request):
	return render_to_response('bootdisp.html', {'Codes': reversed(modelCode.objects.all())})


# To view code
def codeID(request, code_id = 1):
	return render_to_response('bootcodeid.html', {'code': modelCode.objects.get(id = code_id)})


# To edit the submitted Code
def edit_view(request, code_id):
	# print 'in edit_view'
	instance = modelCode.objects.get(id = code_id)
	if request.method == "POST":
		form = CodeForm(request.POST, instance = instance)
		if form.is_valid():
			return CodeCompileRun(request, form)
	
	else: form = CodeForm(instance = instance)
	return render(request, 'bootedit.html', {'form':form, 'code':instance})
