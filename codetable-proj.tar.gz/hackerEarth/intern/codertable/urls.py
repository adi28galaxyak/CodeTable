from django.conf.urls import url

from . import views

urlpatterns = [
    url(r'^all/$', views.AllCodes),
    url(r'^compilemsg/$', views.compilemsg, name = 'compilemsg'),
    url(r'^compilestatus/$', views.compilestatus, name = 'compilestatus'),
    url(r'^runstatus/$', views.runstatus, name = 'runstatus'),
    url(r'^get/(?P<code_id>\d+)/$', views.codeID),
    url(r'^edit/(?P<code_id>\d+)/$', views.edit_view),
    url(r'^create/$', views.create),
    url(r'home/$', views.home),    
] 