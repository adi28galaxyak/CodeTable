# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models, migrations


class Migration(migrations.Migration):

    dependencies = [
        ('codertable', '0010_auto_20160411_1928'),
    ]

    operations = [
        migrations.AddField(
            model_name='modelcode',
            name='outputs',
            field=models.TextField(default=b'Standard output is empty', blank=True),
        ),
    ]
