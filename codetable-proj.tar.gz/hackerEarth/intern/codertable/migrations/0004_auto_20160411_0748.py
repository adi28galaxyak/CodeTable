# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models, migrations


class Migration(migrations.Migration):

    dependencies = [
        ('codertable', '0003_modelcode'),
    ]

    operations = [
        migrations.AddField(
            model_name='modelcode',
            name='year_in_school',
            field=models.CharField(default=b'FR', max_length=2, choices=[(b'FR', b'Freshman'), (b'SO', b'Sophomore'), (b'JR', b'Junior'), (b'SR', b'Senior')]),
        ),
        migrations.AlterField(
            model_name='modelcode',
            name='codearea',
            field=models.TextField(default=b'Write your code here'),
        ),
        migrations.AlterField(
            model_name='modelcode',
            name='inputs',
            field=models.TextField(default=b' '),
        ),
    ]
