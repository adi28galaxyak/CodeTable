# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models, migrations


class Migration(migrations.Migration):

    dependencies = [
        ('codertable', '0009_modelcode_status_details'),
    ]

    operations = [
        migrations.RenameField(
            model_name='modelcode',
            old_name='status_details',
            new_name='status_detail',
        ),
    ]
