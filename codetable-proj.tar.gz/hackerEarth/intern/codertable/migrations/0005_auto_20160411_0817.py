# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models, migrations


class Migration(migrations.Migration):

    dependencies = [
        ('codertable', '0004_auto_20160411_0748'),
    ]

    operations = [
        migrations.RemoveField(
            model_name='modelcode',
            name='year_in_school',
        ),
        migrations.AddField(
            model_name='modelcode',
            name='langchoices',
            field=models.CharField(default=b'C', max_length=2, choices=[(b'C', b'C (gcc 4.8.4)'), (b'CPP', b'C++ (g++ 4.8.4)'), (b'CLOJURE', b'Clojure (clojure 1.4.0)'), (b'CSS', b'CSS'), (b'CSHARP', b'C# (mono 3.2.8)'), (b'GO', b'Go (go 1.4.2)'), (b'HASKELL', b'Haskell (ghc 7.6.3'), (b'HTML', b'HTML'), (b'JAVA', b'Java (openjdk 1.7.0_09)'), (b'JAVASCRIPT_NODE', b'JavaScript (Node.js 0.10.25)'), (b'LISP', b'Lisp (csc 4.8.0.5)'), (b'OBJECTIVE', b'Objective-C (clang 3.3)'), (b'PASCAL', b'Pascal (fpc 2.6.2)'), (b'PERL', b'Perl (perl 5.18.2)'), (b'PHP', b'PHP (php 5.5.9)'), (b'PYTHON', b'Python (python 2.7.6)'), (b'RUBY', b'Ruby (ruby 2.1.1)'), (b'R', b'R (RScript 3.0.2)'), (b'RUST', b'Rust (rustc 1.4.0)'), (b'SCALA', b'Scala (scalac 2.9.2)'), (b'TEXTFILE', b'Text')]),
        ),
    ]
