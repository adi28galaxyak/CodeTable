# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models, migrations
from decimal import Decimal


class Migration(migrations.Migration):

    dependencies = [
        ('codertable', '0006_auto_20160411_0859'),
    ]

    operations = [
        migrations.AddField(
            model_name='modelcode',
            name='mem',
            field=models.DecimalField(default=Decimal('0.00'), max_digits=5, decimal_places=2),
        ),
        migrations.AddField(
            model_name='modelcode',
            name='result',
            field=models.CharField(default=b'AC', max_length=5),
        ),
        migrations.AddField(
            model_name='modelcode',
            name='time',
            field=models.DecimalField(default=Decimal('0.00'), max_digits=2, decimal_places=2),
        ),
    ]
