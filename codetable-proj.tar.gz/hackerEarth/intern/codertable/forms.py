from django import forms
from codertable.models import modelCode

class CodeForm(forms.ModelForm):

	class Meta:
		model = modelCode
		fields = ['codearea', 'inputs', 'langchoices']
		widgets = {
            'codearea': forms.Textarea(attrs={'cols': 80, 'rows': 30, 'placeholder': 'Enter your code here'}),
            'inputs': forms.Textarea(attrs={'cols':35, 'rows':10, 'placeholder': 'You can provide your inputs here'})
        }